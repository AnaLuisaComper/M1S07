package M1S07.M1S07;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class M1S07ApplicationTests {

	@Test
	void contextLoads() {
	}

}
