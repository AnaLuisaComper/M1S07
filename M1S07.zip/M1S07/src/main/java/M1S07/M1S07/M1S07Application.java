package M1S07.M1S07;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class M1S07Application {

	public static void main(String[] args) {
		SpringApplication.run(M1S07Application.class, args);
	}

}
